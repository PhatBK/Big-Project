const IdefineService = require('../commons/idefine_service');
const TimeNormal = require('../commons/functions');

module.exports = function(req,res,next) {
    if(req.method === 'POST' 
    // && 
    //   (
    //       req.headers.service_token === IdefineService.KenhHai.web ||
    //       req.headers.service_token === IdefineService.MyClip.web ||
    //       req.headers.service_token === IdefineService.VideoHay.we ||
    //       req.headers.service_token === IdefineService.FiveDMax.web
    //   )
    ) {
        if (req.body.ip_public === null) {
            req.body.ip_public = "10.10.10.10";
        }
        if (req.body.ip_private === null) {
            req.body.ip_private = "192.168.1.1";
        }
        if (req.body.user_id === null) {
            req.body.user_id = "anonymouse_888666_undefined_userid";
        }
        if (req.body.time === null) {
            req.body.time = TimeNormal.timeNormalFormat(new Date());
        }
        if (req.body.user_agent === null) {
            req.body.user_agent = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/71.0.3578.98 Safari/537.36";
        }
        if (req.body.current_uri === null) {
            req.body.current_uri = "/undefined/";
        }
        if (req.body.media_id === null) {
            req.body.media_id = 0;
        }
        if (req.body.media_name === null) {
            req.body.media_name = "media_name_undefined";
        }
        if (req.body.media_category === null) {
            req.body.media_category = "media_category_undefined";
        }
        if (req.body.media_like_count === null) {
            req.body.media_like_count = 0;
        }
        if (req.body.media_viewed === null) {
            req.body.media_viewed = 0;
        }
        if (req.body.media_duration !== null) {
            req.body.media_duration = parseInt(req.body.media_duration);
        }

        next();
    } else {
        res.end("GET/PUT/DELETE/ method not supported or service token not authentication.");
    }
};