var express = require('express');
var router = express.Router();
// var IdefineService = require('../../commons/idefine_service');
var functionUtils = require('../../commons/functions');

// path save data all folder
const path_log_datas = 'cron_tasks/all-data/kenh-hai/';
const path_req = 'cron_tasks/all-data/kenh-hai/req.txt';
// path save data one folder
let totalRequested  = 0;

/**
 * Post Router for receive data log from browser of client wathcing video
 */
router.post('/event/log-datas', function(req, res, next) {

    let services = functionUtils.serviceIdefine(req.headers['service_token'], 4);
    let service_name = services.service_name;
    let service_type = services.service_type;
    let allLogsPath = path_log_datas + functionUtils.dateNormalFormat(new Date()) + '.txt';

    if (functionUtils.checkFileExists(allLogsPath)) {
        console.log("File already exist");
    } else {
        console.log("File undefine");
        functionUtils.createNewFile(allLogsPath);
    }
    totalRequested++;
    
    functionUtils.writeAppendFileRestNormal(
        allLogsPath,
        req.headers['service_token'],
        service_name,
        service_type,
        req.body.userID,
        req.body.mediaInfos.mediaID,
        req.body.mediaInfos.mediaURI,
        JSON.stringify(req.body.mediaInfos.mediaName),
        JSON.stringify(req.body.mediaInfos.mediaCategory),
        JSON.stringify(req.body.userAgent),
        JSON.stringify(req.body.errorMessage),
        req.body.ipPublic,
        req.body.ipPrivate,
        req.body.time,
        req.body.connectType,
        req.body.bitrateNetwork,
        req.body.seekCount,
        req.body.pauseCount,
        req.body.bufferCount,
        req.body.suspendCount,
        req.body.initialLoadTime,
        req.body.mediaInfos.mediaDuration,
        req.body.watchedDuration,
        req.body.bufferDuration,
        req.body.currentTime,
        req.body.errorCode,
    );

    res.status(200).json({
        'data': req.body,
    });
})
// performance event
router.post('/event/performance', function(req, res, next) {
    let services = functionUtils.serviceIdefine(req.headers['service_token'], 4);
    let service_name = services.service_name;
    let service_type = services.service_type;

    let performance = path_performance + functionUtils.dateNormalFormat(new Date()) + '.txt';
    if (functionUtils.checkFileExists(performance)) {
        console.log("File already exist");
    } else {
        console.log("File not created yet");
        functionUtils.createNewFile(performance);
    }
    totalRequested++;
    if (req.headers['service_token'] !== undefined &&
        req.body.user_id !== undefined &&
        req.body.current_uri !== undefined &&
        req.body.ip_public !== undefined &&
        req.body.ip_private !== undefined &&

        req.body.data.pauseCount !== undefined &&
        req.body.data.seekCount !== undefined &&
        req.body.data.bufferCount !== undefined &&
        req.body.data.totalDuration !== undefined && 
        req.body.data.totalDuration !== 0 &&
        req.body.data.watchedDuration !== undefined &&
        req.body.data.bufferDuration !== undefined &&
        req.body.data.initialLoadTime !== undefined &&

        req.body.time !== undefined &&
        req.body.user_agent !== undefined &&

        req.body.media_id !== undefined &&
        req.body.media_name !== undefined && 
        req.body.media_category !== undefined &&
        req.body.media_like_count !== undefined &&
        req.body.media_viewed !== undefined &&
        req.body.media_duration !== undefined &&
        req.body.data.suspendCount !== undefined
    ) {
        functionUtils.writeAppendFileRestNormal(performance, 
            req.headers['service_token'],
            req.body.user_id,
            req.body.current_uri,
            req.body.ip_public,
            req.body.ip_private,

            req.body.data.pauseCount, 
            req.body.data.seekCount, 
            req.body.data.bufferCount, 
            req.body.data.totalDuration, 
            req.body.data.watchedDuration, 
            req.body.data.bufferDuration, 
            req.body.data.initialLoadTime,

            req.body.time,
            JSON.stringify(req.body.user_agent),

            req.body.media_id,
            JSON.stringify(req.body.media_name),
            req.body.media_category,
            req.body.media_like_count,
            req.body.media_viewed,
            req.body.media_duration,

            req.body.data.suspendCount,
            service_name,
            service_type,

        );
        res.status(200).json({
            'status': "Successed",
            'data': req.body,
            'number_req': totalRequested,
        });
    } else {
        console.log('Request not allowed...');
        res.status(405).json({
            'event': 'Performance',
            'status': 'Failure',
            'error_code': 405,
            'message': 'Request not container full field...',
        });
    }
    
});

module.exports = router;