var express = require('express');
var router = express.Router();
var IdefineService = require('../../commons/idefine_service');
var functionUtils = require('../../commons/functions');
// path save data all folder
const path_data_buffer = 'cron_tasks/all-data/buffered/';
const path_data_error = 'cron_tasks/all-data/error/';
const path_data_first_load = 'cron_tasks/all-data/first-load/';
const path_data_pause = 'cron_tasks/all-data/pause/';
const path_data_performance = 'cron_tasks/all-data/performance/';
const path_data_seek= 'cron_tasks/all-data/seek/';
const path_data_percentile = 'cron_tasks/all-data/percentile/';
const path_data_quality = 'cron_tasks/all-data/quality/';
// path save data one folder
const path_buffered = 'cron_tasks/kenh-hai/buffered/';
const path_error = 'cron_tasks/kenh-hai/error/';
const path_first_load = 'cron_tasks/kenh-hai/first-load/';
const path_pause = 'cron_tasks/kenh-hai/pause/';
const path_performance = 'cron_tasks/kenh-hai/performance/';
const path_seek = 'cron_tasks/kenh-hai/seek/';
const path_quarter = 'cron_tasks/kenh-hai/percentile/';
const path_quality = 'cron_tasks/kenh-hai/quality/';

let totalRequested  = 0;

/* Post home page. */
router.post('/event/log-datas', function(req, res, next) {
    console.log(req.body);
    res.status(200).json(
        {
            'status': 'Successed'
        }
    );
});

router.post('/event/error', function(req, res, next) {
    let errors = path_error + functionUtils.dateNormalFormat(new Date()) + '.txt';
    if (functionUtils.checkFileExists(errors)) {
        console.log("File already exist");
    } else {
        console.log("File undefine");
        functionUtils.createNewFile(errors);
    }
    totalRequested++;
    if (req.headers['service_token'] !== undefined &&
        req.body.user_id !== undefined &&
        req.body.current_uri !== undefined &&
        req.body.ip_public !== undefined &&
        req.body.ip_private !== undefined &&

        req.body.error_code !== undefined &&
        req.body.error_type !== undefined &&
        req.body.error_message !== undefined &&


        req.body.time !== undefined &&
        req.body.user_agent !== undefined &&

        req.body.media_id !== undefined &&
        req.body.media_name !== undefined && 
        req.body.media_category !== undefined &&
        req.body.media_like_count !== undefined &&
        req.body.media_viewed !== undefined &&
        req.body.media_duration !== undefined
    ) {
        functionUtils.writeAppendFileRestNormal(errors,
            req.headers['service_token'],
            req.body.user_id,
            req.body.current_uri,
            req.body.ip_public,
            req.body.ip_private,
            req.body.time,

            req.body.error_code,
            req.body.error_type,
            JSON.stringify(req.body.error_message),
            JSON.stringify(req.body.user_agent),

            req.body.media_id,
            JSON.stringify(req.body.media_name),
            req.body.media_category,
            req.body.media_like_count,
            req.body.media_viewed,
            req.body.media_duration,
        );
        res.status(200).json(
        {
            'status': "Successed",
            'data': req.body,
            'number_req': totalRequested,
        });

    } else {
        res.status(405).json({
            'event': 'Errors',
            'status': 'Failure',
            'error_code': 405,
            'message': 'Request not container full field...',
        });
    }
});

router.post('/event/first-play', function(req, res, next) {
    let first_play = path_first_load + functionUtils.dateNormalFormat(new Date()) + '.txt';
    if (functionUtils.checkFileExists(first_play)) {
        console.log("File already exist");
    } else {
        console.log("File not created yet");
        functionUtils.createNewFile(first_play);
    }
    totalRequested++;
    if (req.headers['service_token'] !== undefined &&
        req.body.user_id !== undefined &&
        req.body.current_uri !== undefined &&
        req.body.ip_public !== undefined &&
        req.body.ip_private !== undefined &&

        req.body.secondsToLoad !== undefined &&

        req.body.time !== undefined &&
        req.body.user_agent !== undefined &&

        req.body.media_id !== undefined &&
        req.body.media_name !== undefined && 
        req.body.media_category !== undefined &&
        req.body.media_like_count !== undefined &&
        req.body.media_viewed !== undefined &&
        req.body.media_duration !== undefined
    ) {
        if (req.body.data.secondsToLoad > req.body.media_duration) {
            req.body.data.secondsToLoad = req.body.media_duration / 2;
        }
        totalRequested += 1;
        functionUtils.writeAppendFileRestNormal(first_play,
            req.headers['service_token'],
            req.body.user_id,
            req.body.current_uri,
            req.body.ip_public,
            req.body.ip_private,

            req.body.secondsToLoad,

            req.body.time,
            JSON.stringify(req.body.user_agent),

            req.body.media_id,
            JSON.stringify(req.body.media_name),
            req.body.media_category,
            req.body.media_like_count,
            req.body.media_viewed,
            req.body.media_duration,
        );
        res.status(200).json(
        {
            'status': "Successed",
            'data': req.body,
            'number_req': totalRequested,
        });
    } else {
        res.status(405).json({
            'event': 'First-Play',
            'status': 'Failure',
            'error_code': 405,
            'message': 'Request not container full field...',
        });
    }

});

router.post('/event/first-quarter', function(req, res, next) {
    let first_quarter = path_quarter + functionUtils.dateNormalFormat(new Date()) + '.txt';
    if (functionUtils.checkFileExists(first_quarter)) {
        console.log("File already exist");
    } else {
        console.log("File not created yet");
        functionUtils.createNewFile(first_quarter);
    }

    totalRequested++;
    if (req.headers['service_token'] !== undefined &&
        req.body.user_id !== undefined &&
        req.body.current_uri !== undefined &&
        req.body.ip_public !== undefined &&
        req.body.ip_private !== undefined &&

        req.body.seekCount !== undefined &&
        req.body.pauseCount !== undefined &&
        req.body.currentTime !== undefined &&
        req.body.duration !== undefined && req.body.data.duration !== 0 &&

        req.body.time !== undefined &&
        req.body.user_agent !== undefined &&

        req.body.media_id !== undefined &&
        req.body.media_name !== undefined && 
        req.body.media_category !== undefined &&
        req.body.media_like_count !== undefined &&
        req.body.media_viewed !== undefined &&
        req.body.media_duration !== undefined
    ) {
        functionUtils.writeAppendFileRestNormal(first_quarter,
            req.headers['service_token'],
            req.body.user_id,
            req.body.current_uri,
            req.body.ip_public,
            req.body.ip_private,

            req.body.seekCount,
            req.body.pauseCount,
            req.body.currentTime,
            req.body.duration,

            req.body.time,
            JSON.stringify(req.body.user_agent),

            req.body.media_id,
            JSON.stringify(req.body.media_name),
            req.body.media_category,
            req.body.media_like_count,
            req.body.media_viewed,
            req.body.media_duration,

            "FIRST",
        );
        res.status(200).json(
        {
            'status': "Successed",
            'data': req.body,
            'number_req': totalRequested,
        });
    } else {
        res.status(405).json({
            'event': 'First-quarter',
            'status': 'Failure',
            'error_code': 405,
            'message': 'Request not container full field...',
        });
    }

});

router.post('/event/second-quarter', function(req, res, next) {
    let second_quarter = path_quarter + functionUtils.dateNormalFormat(new Date()) + '.txt';
    if (functionUtils.checkFileExists(second_quarter)) {
        console.log("File already exist");
    } else {
        console.log("File not created yet");
        functionUtils.createNewFile(second_quarter);
    }
    totalRequested++;
    if (req.headers['service_token'] !== undefined &&
        req.body.user_id !== undefined &&
        req.body.current_uri !== undefined &&
        req.body.ip_public !== undefined &&
        req.body.ip_private !== undefined &&

        req.body.seekCount !== undefined &&
        req.body.pauseCount !== undefined &&
        req.body.currentTime !== undefined &&
        req.body.duration !== undefined && req.body.data.duration !== 0 &&

        req.body.time !== undefined &&
        req.body.user_agent !== undefined &&

        req.body.media_id !== undefined &&
        req.body.media_name !== undefined && 
        req.body.media_category !== undefined &&
        req.body.media_like_count !== undefined &&
        req.body.media_viewed !== undefined &&
        req.body.media_duration !== undefined
    ) {
        functionUtils.writeAppendFileRestNormal(second_quarter,
            req.headers['service_token'],
            req.body.user_id,
            req.body.current_uri,
            req.body.ip_public,
            req.body.ip_private,

            req.body.seekCount,
            req.body.pauseCount,
            req.body.currentTime,
            req.body.duration,

            req.body.time,
            JSON.stringify(req.body.user_agent),

            req.body.media_id,
            JSON.stringify(req.body.media_name),
            req.body.media_category,
            req.body.media_like_count,
            req.body.media_viewed,
            req.body.media_duration,

            "SECOND",
        );
        res.status(200).json(
        {
            'status': "Successed",
            'data': req.body,
            'number_req': totalRequested,
        });
    } else {
        res.status(405).json({
            'event': 'Second-quarter',
            'status': 'Failure',
            'error_code': 405,
            'message': 'Request not container full field...',
        });
    }
    
});

router.post('/event/third-quarter', function(req, res, next) {
  
    let third_quarter = path_quarter + functionUtils.dateNormalFormat(new Date()) + '.txt';
    if (functionUtils.checkFileExists(third_quarter)) {
        console.log("File already exist");
    } else {
        console.log("File not created yet");
        functionUtils.createNewFile(third_quarter);
    }
    totalRequested++;
    if (req.headers['service_token'] !== undefined &&
        req.body.user_id !== undefined &&
        req.body.current_uri !== undefined &&
        req.body.ip_public !== undefined &&
        req.body.ip_private !== undefined &&

        req.body.seekCount !== undefined &&
        req.body.pauseCount !== undefined &&
        req.body.currentTime !== undefined &&
        req.body.duration !== undefined && req.body.data.duration !== 0 &&

        req.body.time !== undefined &&
        req.body.user_agent !== undefined &&

        req.body.media_id !== undefined &&
        req.body.media_name !== undefined && 
        req.body.media_category !== undefined &&
        req.body.media_like_count !== undefined &&
        req.body.media_viewed !== undefined &&
        req.body.media_duration !== undefined
    ) {
        functionUtils.writeAppendFileRestNormal(third_quarter,
            req.headers['service_token'],
            req.body.user_id,
            req.body.current_uri,
            req.body.ip_public,
            req.body.ip_private,

            req.body.seekCount,
            req.body.pauseCount,
            req.body.currentTime,
            req.body.duration,

            req.body.time,
            JSON.stringify(req.body.user_agent),

            req.body.media_id,
            JSON.stringify(req.body.media_name),
            req.body.media_category,
            req.body.media_like_count,
            req.body.media_viewed,
            req.body.media_duration,

            "THIRD",
        );
        res.status(200).json(
        {
            'status': "Successed",
            'data': req.body,
            'number_req': totalRequested,
        });
    } else {
        res.status(405).json({
            'event': 'Third-quarter',
            'status': 'Failure',
            'error_code': 405,
            'message': 'Request not container full field...',
        });
    }
    
});

router.post('/event/fourth-quarter', function(req, res, next) {
    let fourth_quarter = path_quarter + functionUtils.dateNormalFormat(new Date()) + '.txt';
    if (functionUtils.checkFileExists(fourth_quarter)) {
        console.log("File already exist");
    } else {
        console.log("File not created yet");
        functionUtils.createNewFile(fourth_quarter);
    }
    totalRequested++;
    if (req.headers['service_token'] !== undefined &&
        req.body.user_id !== undefined &&
        req.body.current_uri !== undefined &&
        req.body.ip_public !== undefined &&
        req.body.ip_private !== undefined &&

        req.body.seekCount !== undefined &&
        req.body.pauseCount !== undefined &&
        req.body.currentTime !== undefined &&
        req.body.duration !== undefined && req.body.data.duration !== 0 &&

        req.body.time !== undefined &&
        req.body.user_agent !== undefined &&

        req.body.media_id !== undefined &&
        req.body.media_name !== undefined && 
        req.body.media_category !== undefined &&
        req.body.media_like_count !== undefined &&
        req.body.media_viewed !== undefined &&
        req.body.media_duration !== undefined
    ) {
        functionUtils.writeAppendFileRestNormal(fourth_quarter,
            req.headers['service_token'],
            req.body.user_id,
            req.body.current_uri,
            req.body.ip_public,
            req.body.ip_private,

            req.body.seekCount,
            req.body.pauseCount,
            req.body.currentTime,
            req.body.duration,

            req.body.time,
            JSON.stringify(req.body.user_agent),

            req.body.media_id,
            JSON.stringify(req.body.media_name),
            req.body.media_category,
            req.body.media_like_count,
            req.body.media_viewed,
            req.body.media_duration,

            "FOURTH",
        );
        res.status(200).json(
        {
            'status': "Successed",
            'data': req.body,
            'number_req': totalRequested,
        });
    } else {
        res.status(405).json({
            'event': 'Fourth-quarter',
            'status': 'Failure',
            'error_code': 405,
            'message': 'Request not container full field...',
        });
    }
});

router.post('/event/buffered', function(req, res, next) {
    let buffered = path_buffered + functionUtils.dateNormalFormat(new Date()) + '.txt';
    if (functionUtils.checkFileExists(buffered)) {
        console.log("File already exist");
    } else {
        console.log("File not created yet");
        functionUtils.createNewFile(buffered);
    }
    totalRequested++;
    if (req.headers['service_token'] !== undefined &&
        req.body.user_id !== undefined &&
        req.body.current_uri !== undefined &&
        req.body.ip_public !== undefined &&
        req.body.ip_private !== undefined &&

        req.body.currentTime !== undefined &&
        req.body.readyState !== undefined &&
        req.body.secondsToLoad !== undefined &&
        req.body.bufferCount !== undefined &&

        req.body.time !== undefined &&
        req.body.user_agent !== undefined && 

        req.body.media_id !== undefined &&
        req.body.media_name !== undefined && 
        req.body.media_category !== undefined &&
        req.body.media_like_count !== undefined &&
        req.body.media_viewed !== undefined &&
        req.body.media_duration !== undefined
    ) {
        functionUtils.writeAppendFileRestNormal(buffered,
            req.headers['service_token'],
            req.body.user_id,
            req.body.current_uri,
            req.body.ip_public,
            req.body.ip_private,

            req.body.currentTime,
            req.body.readyState, 
            req.body.secondsToLoad, 
            req.body.bufferCount,

            req.body.time,
            JSON.stringify(req.body.user_agent),

            req.body.media_id,
            JSON.stringify(req.body.media_name),
            req.body.media_category,
            req.body.media_like_count,
            req.body.media_viewed,
            req.body.media_duration,
        );
        res.status(200).json({
            'status': "Successed",
            'data': req.body,
            'number_req': totalRequested,
        });
    } else {
        res.status(405).json({
            'event': 'Buffered',
            'status': 'Failure',
            'error_code': 405,
            'message': 'Request not container full field...',
        });
    }
});

router.post('/event/seek', function(req, res, next) {
    let seek = path_seek + functionUtils.dateNormalFormat(new Date()) + '.txt';
    if (functionUtils.checkFileExists(seek)) {
        console.log("File already exist");
    } else {
        console.log("File not created yet");
        functionUtils.createNewFile(seek);
    }
    totalRequested++;
    if (req.headers['service_token'] !== undefined &&
        req.body.user_id !== undefined &&
        req.body.current_uri !== undefined &&
        req.body.ip_public !== undefined &&
        req.body.ip_private !== undefined &&

        req.body.seekCount !== undefined &&
        req.body.seekTo !== undefined &&

        req.body.time !== undefined &&
        req.body.user_agent !== undefined && 

        req.body.media_id !== undefined &&
        req.body.media_name !== undefined && 
        req.body.media_category !== undefined &&
        req.body.media_like_count !== undefined &&
        req.body.media_viewed !== undefined &&
        req.body.media_duration !== undefined

    ) {
        functionUtils.writeAppendFileRestNormal(seek, 
            req.headers['service_token'],
            req.body.user_id,
            req.body.current_uri,
            req.body.ip_public,
            req.body.ip_private,
            
            req.body.seekCount, 
            req.body.seekTo,

            req.body.time,
            JSON.stringify(req.body.user_agent),

            req.body.media_id,
            JSON.stringify(req.body.media_name),
            req.body.media_category,
            req.body.media_like_count,
            req.body.media_viewed,
            req.body.media_duration,
        );
        res.status(200).json({
            'status': "Successed",
            'data': req.body,
            'number_req': totalRequested,
        });
    } else {
        res.status(405).json({
            'event': 'Seek',
            'status': 'Failure',
            'error_code': 405,
            'message': 'Request not container full field...',
        });
    }
    
});
// send all data when video finished or reload
router.post('/event/performance', function(req, res, next) {
    let performance = path_performance + functionUtils.dateNormalFormat(new Date()) + '.txt';
    if (functionUtils.checkFileExists(performance)) {
        console.log("File already exist");
    } else {
        console.log("File not created yet");
        functionUtils.createNewFile(performance);
    }
    totalRequested++;
    if (req.headers['service_token'] !== undefined &&
        req.body.user_id !== undefined &&
        req.body.current_uri !== undefined &&
        req.body.ip_public !== undefined &&
        req.body.ip_private !== undefined &&

        req.body.pauseCount !== undefined &&
        req.body.seekCount !== undefined &&
        req.body.bufferCount !== undefined &&
        req.body.totalDuration !== undefined && req.body.data.totalDuration !== 0 &&
        req.body.watchedDuration !== undefined &&
        req.body.bufferDuration !== undefined &&
        req.body.initialLoadTime !== undefined &&

        req.body.time !== undefined &&
        req.body.user_agent !== undefined &&

        req.body.media_id !== undefined &&
        req.body.media_name !== undefined && 
        req.body.media_category !== undefined &&
        req.body.media_like_count !== undefined &&
        req.body.media_viewed !== undefined &&
        req.body.media_duration !== undefined
    ) {
        functionUtils.writeAppendFileRestNormal(performance, 
            req.headers['service_token'],
            req.body.user_id,
            req.body.current_uri,
            req.body.ip_public,
            req.body.ip_private,

            req.body.pauseCount, 
            req.body.seekCount, 
            req.body.bufferCount, 
            req.body.totalDuration, 
            req.body.watchedDuration, 
            req.body.bufferDuration, 
            req.body.initialLoadTime,

            req.body.time,
            JSON.stringify(req.body.user_agent),

            req.body.media_id,
            JSON.stringify(req.body.media_name),
            req.body.media_category,
            req.body.media_like_count,
            req.body.media_viewed,
            req.body.media_duration,
        );
        res.status(200).json({
            'status': "Successed",
            'data': req.body,
            'number_req': totalRequested,
        });
    } else {
        res.status(405).json({
            'event': 'Performance',
            'status': 'Failure',
            'error_code': 405,
            'message': 'Request not container full field...',
        });
    }
    
});

module.exports = router;