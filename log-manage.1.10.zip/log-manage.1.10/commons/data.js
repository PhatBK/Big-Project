const body = {
    'mediaInfos': {
        'mediaID': null,
        'mediaName': null,
        'mediaURI': null,
        'mediaCategory': null,
        'mediaDuration': 0,
    },
    'userID': null,
    'ipPublic': null,
    'ipPrivate': null,
    'userAgent': null,
    'time': null,
    'bitrateNetwork': 0,
    'connectType': null,

    'seekCount': 0,
    'pauseCount': 0,
    'bufferCount': 0,
    'suspendCount': 0,

    'initialLoadTime': 0,
    'watchedDuration': 0,
    'bufferDuration': 0,
    'currentTime': 0,

    'errorCode': null,
    'errorMessage': null,

}

module.exports.body = body;