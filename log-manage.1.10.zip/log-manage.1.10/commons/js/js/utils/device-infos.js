const device_infos = {

};