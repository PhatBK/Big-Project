
// player.on('loadstart', function() {
//     console.log(player.bufferedPercent());
// });
// player.on('loadeddata', function() {
//     console.log(player.bufferedPercent());
// });
// player.on('loadedmetadata', function() {
//     console.log(player.bufferedPercent());
// });
// player.on('timeupdate', function() {
// 	// console.log(player.error());
// 	// console.log(player.currentTime());
// });
// player.on('play', function() {
//     console.log(player.bufferedPercent());
// });
// player.on('error', function() {

// });
// player.on('seeking', function() {
//     console.log(player.bufferedPercent());
// });
// player.on('seeked', function() {
//     console.log(player.bufferedPercent());
// });
// player.on('waiting', function() {
//     console.log(player.currentTime());
// });

// player.on('interruptend', function() {
//     console.log(player.currentTime());
// });
// player.on('ended', function() {
// 	player.dispose();
// });
// player.on('progress', function() {
//     console.log(player.bufferedPercent());
// });
// player.on('playing', function() {
//     console.log(player.currentTime());
// });
// player.on('timeupdate', function() {
//     console.log(player.currentTime());
// });
