// navigator information
const user_agent = navigator.userAgent;
const browser_code = navigator.appCodeName;
const browser_version = navigator.appVersion;
const cookie_enable = navigator.cookieEnabled;
const browser_language = navigator.language;
const browser_online = navigator.onLine;
const browser_name =  navigator.appName;
const user_platform = navigator.platform;
// cookie
const cookie = null;
// ip
const ip_public_address = null;
const ip_private_address = null;
const mac_address = '';

const device_type = "Web";
