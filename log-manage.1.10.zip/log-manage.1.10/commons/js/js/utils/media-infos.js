// define infomation
let media_infos = {
	'current_uri': window.location.pathname,
	'current_src': document.getElementById('video-src').src,
	'media_id': '',
	'media_category': '',
	'media_name': '',
	'media_duration': '',
	'media_viewed': '',
	'media_like_count': '',
};

// code get information here
